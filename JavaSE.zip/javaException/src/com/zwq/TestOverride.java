package com.zwq;

import java.io.FileNotFoundException;
import java.io.IOException;
//子类重写父类的方法，其抛出的异常类型只能是被重写方法的异常类的子类或异常类型一样
public class TestOverride {

	public static void main(String[] args) {
		// TODO 自动生成的方法存根
        
	}
	
	
	class A {
		public void  method1() throws IOException {
			
		}
	}
	
	class B extends A {
		public void method1() throws FileNotFoundException {
			
		}
	}

}
