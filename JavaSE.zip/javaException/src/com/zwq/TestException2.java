package com.zwq;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Date;
import java.util.Scanner;

import org.junit.Test;

/**
 * 二 如何处理Exception的异常
 * Java提供的是异常处理的抓抛模型
 *  1. “抛”：当我们执行代码时，一旦出现异常，就会在异常的代码处生成一个对应的异常类型的对象，
 *    并将此对象抛出(自动抛出   /  手动抛出（throw+异常类的对象）)
 *   >一旦抛出此异常类的对象，那么程序就终止执行
 *   >此异常类的对象抛给方法的调用者
 *   
 *  2. “抓”： 抓住上一步抛出来的异常类的对象，如何抓？即为异常处理的方式
 *  java提供两种方式来处理一个异常类的对象。
 *  处理方式一：（throws）
 *  处理的方式二（try-catch-finally）：
 *    try{
 *       //可能出现异常的代码
 *    } catch(Exception e1) {
 *       //处理方式1
 *    } catch(Exception e2) {
 *       //处理方式2
 *    } finally {
 *         //不管是否出现异常都会执行
 *    }
 * 
 * 注：1. try内声明的变量，类似于局部变量，出了try{}语句，就不能被调用
 *    2. finally是可选的
 *    3. catch语句内部是对异常对象的处理
 *         >getMessage();  printStackTrace();
 *    4. 可以有多个catch语句，try中抛出的异常类对象从上往下去匹配，一旦满足就执行catch中的语句。执行完，就不在执行后面的catch语句
 *    5. 如何异常处理了，那么其后的代码可以继续执行
 *    6. 若catch中多个异常类型是“并列”关系，孰上孰下都可以
 *       若catch中多个异常类型是“包含”关系，需将子类放在父类的上面，否则报错
 *    7. finally中存放的是一定会被执行的代码，不管try中，catch中是否仍有异常未被处理
 *    8. try-catch是可以嵌套的
 * 三 对于运行时异常来说，可以不显示的进行处理
 *   对于编译时异常来说，必须要显示的进行处理
 *
 */
public class TestException2 {

	//编译时异常
	@Test
	public void test6() {
		
		try {
			FileInputStream fis = new FileInputStream(new File("hello.txt"));
			int b = 0;
			while((b=fis.read()) != -1) {
				System.out.println((char)b);
		} 
			fis.close();
		}	catch (FileNotFoundException e) {
              System.out.println(e.getMessage());

		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}

	
	
	
	
	
	
	
	
	
	
	//常见的运行时异常
	// 4.空指针异常:NullPointerException
	@Test
	public void test5() {
		Date date = new Date();
		date = null;
		System.out.println(date.toString());
	}
	
	// 3. 类型转换异常:ClassCastException
	@Test
	public void test4() {
		
		try {
			//运行时异常
			Object obj = new Date();
			String str = (String) obj;
		}catch(NullPointerException e) {
			System.out.println("出现空指针异常！");
		} catch (ClassCastException e) {
           System.out.println("出现类型转换的异常了");		
        } catch (Exception e) {
			e.printStackTrace();
		}
	      System.out.println("hello");
	
		//编译时异常
		//String str1 = (String)new Date();
	}
	
	
	
	// 2. 算术异常：
	@Test
	public void test3() {
		try {
			int i = 10;
			System.out.println(i/0);
			
		} catch (Exception e) {
          System.out.println(e.getMessage());//异常简略信息
          e.printStackTrace();//异常详细信息
		}
	}
	
	// 1.数组下标越界异常
	@Test
	public void test2() {
		int[] i = new int[10];
		System.out.println(i[10]);
	}
	
	@Test
	public void test1() {
		Scanner sc = new Scanner(System.in);
		int i = sc.nextInt();
		System.out.println(i);
	}

}
