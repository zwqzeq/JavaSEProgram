package com.zwq;

public class TestError {
	public static void main(String[] args) {
		//Exception in thread "main" java.lang.StackOverflowError
		//main(args);
		
		//Exception in thread "main" java.lang.OutOfMemoryError: Java heap space
        //byte[] b = new byte[1024*1024*600000];		
		
		
		
	}
}
