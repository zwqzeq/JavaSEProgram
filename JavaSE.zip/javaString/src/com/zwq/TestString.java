package com.zwq;

import org.junit.Test;

public class TestString {

	/**
	 * 1. 字符串----->基本数据类型，包装类：调用相应的包装类的parseXXX(String str)
	 * 2. 基本数据类型，包装类------>字符串：调用字符串的重载的valueOf()方法
	 * 
	 * 3. 字符串------->字节数组 调用字符串的getBytes()
	 * 4. 字节数组------>字符串  调用字符串的构造器
	 * 
	 * 5. 字符串------->字符数组 调用字符串的toCharArray()
	 * 6. 字符数组------>字符串   调用字符串的构造器
	 */
	@Test
	public void test5() {
		// 1. 字符串与基本数据类型，包装类之间的转换
		String str1 = "123";
		int i = Integer.parseInt(str1);
		System.out.println(i);

		// 2. 基本数据类型，包装类与字符串之间的转换
		String str2 = i + "";
		str2 = String.valueOf(i);
		System.out.println(str2);
		
		
		// 3. 字符串与字节数组间的转换
		String str3 = "abcd123";
		byte[] b = str3.getBytes();
		for (int j = 0; j < b.length; j++) {
			System.out.println((char)b[j]);
		}
		
		// 4. 字节数组与字符串间的转换
		String str4 = new String(b);
		System.out.println(str4);

		//5.字符串转换为字符数组
		String str5 = "abc123中国人";
		char[] c = str5.toCharArray();
		for (int j = 0; j < c.length; j++) {
			System.out.println(c[j]);		
		}
		//6.字符数组转换为字符串
		String str6 = new String(c);
		System.out.println(str6);
	}

	
	@Test
	public void test3() {
		/**
		 * public String substring(int startpoint) public String substirng(int
		 * start,int end)//返回从start开始到end结束的一个左闭又开的字串 public String replace(char
		 * oldChar,char newChar) public String replaceAll(String old,Stirng new)
		 * public String trim()//去除当前字符串中首尾的空格，若有多个就去除多个 public String
		 * concat(String str) public String[] split(String
		 * regex)//按照regex将当前的字符串拆分，拆分为多个字符串，整体返回值为String[]
		 */

		String str1 = "北京新东方教育北京";
		String str2 = "上海新东方教育";
		String str3 = str1.substring(2);
		String str4 = str1.substring(2, 5);
		System.out.println(str3);
		System.out.println(str4);
		String str5 = str1.replace("北京", "东京");
		String str6 = str1.replaceAll("北京", "东京");
		System.out.println(str5);
		System.out.println(str6);
		String str7 = "     abc   d  ";
		String str8 = str7.trim();
		System.out.println("----" + str8 + "----");
		System.out.println("----" + str7 + "----");
		System.out.println(str1.concat(str2));
		System.out.println("------------------------");

		String str9 = "abc*d-e7f-ke";
		String[] strs = str9.split("-");
		System.out.println(strs);
		for (int i = 0; i < strs.length; i++) {
			System.out.println(strs[i]);
		}

	}

	@Test
	public void test2() {
		/**
		 * public int length() public char charAt(int index) public boolean
		 * equals(Object anObject) public int compareTo(String anotherString)
		 * public int indexOf(String s)//返回s字符串在当前字符串中首次出现的的位置，若没有，返回-1 public
		 * int indexOf(String s,int startPoint) public int lastIndexOf(String s)
		 * public int lastIndexOf(String s,int startPoint) public boolean
		 * startWith(String prefix)//判断当前字符串是否以prefix开始 public boolean
		 * endWith(String suffix) public boolean regionMatches(int
		 * firstStart,String other,int otherStart,int length)
		 *
		 */

		String str1 = "abccdefghijkbcc";
		String str2 = "bcc";
		String str3 = "jkbcc";

		System.out.println(str2.length());// 3
		System.out.println(str1.charAt(2));// 下标从零开始计数
		System.out.println(str1.equals(str2));// false
		System.out.println(str2.equals("bcc"));// true
		System.out.println(str1.compareTo(str2));// -1
		System.out.println(str2.compareTo("bcc"));// 0
		System.out.println(str1.indexOf(str2));// 1
		System.out.println(str1.indexOf(str2, 5));// 12
		System.out.println(str1.lastIndexOf(str2));// 12
		System.out.println(str1.lastIndexOf(str2, 14));// 12
		System.out.println(str1.startsWith("abc"));// true
		System.out.println(str1.endsWith("c"));// true
		System.out.println(str1.regionMatches(10, str3, 0, str3.length()));// true

	}

	@Test
	public void test() {
		String str1 = "JavaEE";
		String str2 = "JavaEE";
		String str3 = new String("JavaEE");
		String str4 = "JavaEE" + "Android";
		String str5 = "Android";
		String str6 = str1 + str5;
		str5 = str5 + "Handoop";
		String str7 = str6.intern();
		String str8 = "JavaEEAndroid";

		// ==比较的是地址; equals()比较的是内容
		System.out.println(str1 == str2);// true
		System.out.println(str1 == str3);// false
		System.out.println(str1.equals(str3));// true
		System.out.println(str4 == str6);// 不是true，而是false
		System.out.println(str4.equals(str6));// true
		System.out.println(str7 == str4);// true
		System.out.println(str4 == str8);// true

		Person p1 = new Person("AA");
		Person p2 = new Person("AA");
		System.out.println("^_^" + (p1 == p2));// false
		System.out.println("^_^" + (p1.equals(p2)));// 不是true，而是false
		System.out.println("^_^" + (p1.name == p2.name));// true
		System.out.println("^_^" + (p1.name.equals(p2.name)));// true

	}
}

class Person {

	String name;

	public Person(String name) {
		this.name = name;
	}

}
