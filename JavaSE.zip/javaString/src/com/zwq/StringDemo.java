package com.zwq;

import static org.hamcrest.CoreMatchers.nullValue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 1. 模拟一个trim方法，去除字符串两端的空格 。
 * 2. 将一个字符串反转，将字符串中指定的部分反转。比如将“abcdefg”反转为“abfedcg”。 
 * 3. 获取一个字符串在另一个字符串中出现的次数.比如：获取“ab”在“abkkcadkabkebfkabkskab”中出现的次数。
 * 4. 获取两个字符串中最大相同字串。比如str1 = “abcweathellooyuiodef” ; str2 = "abcwercvhelloobnm"。
 * 
 */

public class StringDemo {

	public static void main(String[] args) {

		// @Test-myTrim
		String testString1 = "    abc  d    ";
		// 特殊情况
		String testString2 = "              ";

		String str1 = StringDemo.myTrim(testString1);
		String str2 = StringDemo.myTrim(testString2);
		System.out.println("----" + str1 + "----");
		System.out.println("----" + str2 + "----");

		// 验证
		String str3 = str1.trim();
		String str4 = str2.trim();
		System.out.println("----" + str3 + "----");
		System.out.println("----" + str4 + "----");

		// @Test-myReverseString and myReverseArray
		String str5 = "abcdefg";
		String str6 = myReverseString(str5, 2, 5);
		System.out.println("原字符串：" + str5);
		System.out.println("指定部分反转-法一：" + str6);

		String str7 = "abcdefg";
		String str8 = reverseString2(str7, 2, 5);
		System.out.println("指定部分反转-法二：" + str8);

		int count = getTime("abkkcadkabkebfkabkskab", "abk");
		System.out.println("出现次数为：" + count);

	
	    List<String> str9 = getMaxSubString("abcwerathelloyuiodef", "abcwercvhellobnm");
	    System.out.println(str9);
	
	    
	    String str10 = "aediewfn";
	    String str11 = mySort(str10);
	    System.out.println(str11);
	    
	    
	
	}

	
	//5.对字符串中字符进行自然排序
	public static String mySort(String str) {
		char[]c = str.toCharArray();
		Arrays.sort(c);
		return new String(c);
	}
	
	
	
	
	
	
	// 4. 获取两个字符串中最大相同字串。
	public static List<String> getMaxSubString(String str1, String str2) {
		String maxStr = (str1.length() > str2.length())? str1:str2;
		String minStr = (str1.length() < str2.length())? str1:str2;
        int length = minStr.length();
		List<String> list = new ArrayList<String>();
        for (int i = 0; i < length; i++) {
			for (int x = 0,y = length - i; y <= length; x++,y++) {
				String str = minStr.substring(x,y);
			   if (maxStr.contains(str)) {
				   list.add(str);
			   }
			}
			    if (list.size() != 0) {
			    	return list;
			    }
			}
		return null;
	}

	// 3. 获取一个字符串在另一个字符串中出现的次数.
	// 判断str2 在 str1 中出现的次数
	// 比如：获取“ab”在“abkkcadkabkebfkabkskab”中出现的次数取
	public static int getTime(String str1, String str2) {
		int count = 0;
		int length;
		while ((length = str1.indexOf(str2)) != -1) {
			count++;
			str1 = str1.substring(length + str2.length());
		}
		
		return count;
	}

	// 2.2 将一个字符串进行反转。将字符串中指定的部分进行反转（法二）
	public static String reverseString2(String str, int start, int end) {
		String str1 = str.substring(0,start);
		for (int i = end; i >= start; i--) {
            char c = str.charAt(i);
            str1 += c;
		}
		str1 += str.substring(end + 1);
		return str1;
	}

	// 1. 模拟trim方法，去除字符串两端的空格
	public static String myTrim(String str) {
		int start = 0;
		int end = str.length() - 1;
		// 判断字符串str前面是否有空格
		while (start <= end && str.charAt(start) == ' ') {
			start++;
		}
		System.out.println(start);
		// 判断字符串str后面是否有空格，如果不加上start <= end，那么在特殊情况下会出现数组下标越界的异常
		while (start <= end && str.charAt(end) == ' ') {
			end--;
		}
		 System.out.println(end);
		 // 方法一：
		 char[]a = new char[end-start+1];
		 int j = 0;
		 for (int i = start; i <= end; i++,j++) {
		 System.out.print(i+" ");
		 a[j] = str.charAt(i);
		 }
		 System.out.println();
		 //将字符数组转换为字符串
		 String str1 = new String(a);
		 return str1;
		

//		// 方法二：
//		return str.substring(start, end + 1);

	}

	// 2.1 将一个字符串反转，将字符串中指定的部分反转。比如将“abcdefg”反转为“abfedcg”
	public static String myReverseString(String str, int start, int end) {
	    //字符串转换为字符数组
		char[] c = str.toCharArray();	
		return myreverseArray(c, start, end);
	}

	public static String myreverseArray(char[] c, int start, int end){
		for (int i = start,j = end; i < j; i++,j--) {
			char temp = c[i];
			c[i] = c[j];
			c[j] = temp;
		}
		//字符数组转换为字符串
		return new String(c);
	}

}
