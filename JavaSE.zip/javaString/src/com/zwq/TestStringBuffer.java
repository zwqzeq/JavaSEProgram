package com.zwq;

import org.junit.Test;

/**
 * java.lang.StringBuffer,可变的字符序列
 * java.lang.StringBuilder,可变的字符序列,是jdk5.0新加入的，线程不安全，但效率要高于StringBuffer
 * 
 * @author asus
 *
 */
public class TestStringBuffer {

	@Test
	public void test2() {
		long startTime = 0L;
		long endTime = 0L;
		String text = "";
		StringBuffer buffer = new StringBuffer("");
		StringBuilder builder = new StringBuilder("");
		startTime = System.currentTimeMillis();
		for (int i = 0; i < 20000; i++) {
			buffer.append(String.valueOf(i));
		}
		endTime = System.currentTimeMillis();
		System.out.println("StringBuffer的执行时间：" + (endTime - startTime));

		startTime = System.currentTimeMillis();
		for (int i = 0; i < 20000; i++) {
			builder.append(String.valueOf(i));
		}
		endTime = System.currentTimeMillis();
		System.out.println("StringBuilder的执行时间：" + (endTime - startTime));

		startTime = System.currentTimeMillis();
		for (int i = 0; i < 20000; i++) {
			text = text + i;
		}
		endTime = System.currentTimeMillis();
		System.out.println("String的执行时间：" + (endTime - startTime));

	}

	/**
	 * java.lang.StringBuffer:代表可变的字符序列，可以对字符串内容进行增删 StringBuffer append(String
	 * s) , StringBuffer append(int n), StringBuffer append(Object o) ,
	 * StringBuffer append(char n), StringBuffer append(long n) , StringBuffer
	 * append(boolean n), StringBuffer insert(int index,String str) public
	 * StringBuffer reverse() public void setCharAt(int n,char ch) StringBuffer
	 * replace(int startIndex , int endIndex , String str) public int
	 * indexOf(String str) public String subString(int start,int end)
	 * 总结：添加：append，删 delete，改 setCharAt(int index,char ch)，查charAt 插入：insert
	 * ，反转reverse ，长度length
	 *
	 *
	 */

	@Test
	public void test() {
		StringBuffer sb = new StringBuffer();
		System.out.println(sb.length());
		sb.append("abc").append("123").append(true);
		System.out.println(sb);
		sb.insert(2, "hello");
		System.out.println(sb);
		StringBuffer sb2 = sb.reverse();
		System.out.println(sb2);
		// 左闭右开
		StringBuffer sb3 = sb.delete(2, 7);
		System.out.println(sb3);
		char c = sb.charAt(2);
		System.out.println(c);
	}

}
