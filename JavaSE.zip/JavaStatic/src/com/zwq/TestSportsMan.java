package com.zwq;

/*
 * static,静态的，可以用来修饰：属性，方法，代码块（或初始化块），内部类
 * 1.由类创建的所有的对象，都共用这一个属性
 * 2.当其中一个对象对此属性进行修改，会导致其他对象对此属性的一个调用。VS 实例变量（非static修饰的属性，各个对象各自拥有一套副本）
 * 3.类变量随着类的加载而加载，而且独一份
 * 4.静态的变量可以直接通过“类.类变量”的形式来调用
 * 5.类变量的加载是要早于对象。所以当有对象以后，可以“对象.类变量”使用。但是“类.实例变量”是不可以的
 * 6.类变量存在于静态域中
 * 
 * 
 * static修饰方法（类方法）：
 * 1.随着类的加载而加载，在内存中也是独一份
 * 
 * 2.可以直接通过“类.类方法” 的方式调用
 * 3.内部可以调用静态的属性或静态的方法，而不能调用非静态的属性或方法。反之，非静态的方法可以调用静态的方法，原因就是：静态的方法生命周期要早于非静态的方法
 * 
 * >静态的方法内是不可以有this或者super关键字的!
 * 注：静态的结构(static的属性，方法，代码块，内部类)的生命周期要早于非静态的结构，同时被回收也要晚于非静态的
 * 
 */
public class TestSportsMan {
	public static void main(String[] args) {
		SportsMan s1 = new SportsMan("金龙",23);
		SportsMan s2 = new SportsMan("银龙",21);
		s1.name = "花龙";
		s1.nation = "中国";
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(SportsMan.nation);
		s1.show();
		s1.show1();
		SportsMan.show1();
		
		
		
		
	}
}
class SportsMan {
	//实例变量---只有创建了对象之后，才有实例变量
	String name;
	int age;
	//类变量---类变量随着类的加载而加载，在创建对象之前就已经有了
	static String nation; //所有对象共有
	public SportsMan(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}
	public SportsMan(String name, int age, String nation) {
		super();
		this.name = name;
		this.age = age;
		this.nation = nation;
	}
	public SportsMan() {
		super();
	}
	@Override
	public String toString() {
		return "SportsMan [name=" + name + ", age=" + age + ", nation=" + nation + "]";
	}
	
	public void show() {
		System.out.println("age:" + this.age);
		System.out.println("nation:"+nation);
		info();
		System.out.println("我来自中国！");
	}
	
	public static void show1() {
		System.out.println("nation:" + nation);
		info();
		//System.out.println("age:" + this.age);//不能使用
		System.out.println("我来自中国！");
	}
	
	public static void info() {
		System.out.println("我是静态的方法！");
	}
	
	
	
	
}