package com.exercise;

class Root {
	static {
		System.out.println("Root的静态初始化块");
	}
	
	{
		System.out.println("Root的普通初始化块");
	}

	public Root() {
		super();
		System.out.println("Root的无参数的构造器");
	}
	
	
}



class Mid extends Root {
	String msg;
	static {
		System.out.println("Mid的静态初始化块");
	}
    {
		System.out.println("Mid的普通初始化块");
	}
    
    public Mid() {
    	System.out.println("Mid的无参数的构造器");
    }

	public Mid(String msg) {
		super();
		this.msg = msg;
		System.out.println("Mid的带参数构造器，其参数值：" + msg);
	}   
}

class Leaf extends Mid {
	static {
		System.out.println("Leaf的静态初始化块");
	}
    {
		System.out.println("Leaf的普通初始化块");
	}
    
    public Leaf() {
    	super("我是中国人！");
    	System.out.println("执行Leaf的构造器");
    }

}


public class TestLeaf {
    public static void main(String[] args) {
		new Leaf();
		System.out.println();
		new Leaf();
	}
}
