package com.zwq;

import static org.hamcrest.CoreMatchers.nullValue;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

import org.junit.Test;

/*
 *   Collection接口
 *          |-------List接口：存储有序，可重复的元素
 *               |--------Vector(古老的实现类，线程安全的，但效率低于ArrayList)，
 *               |--------ArrayList(主要的实现类),
 *               |--------LinkedList(对于频繁的插入，删除操作)
 *
 *          |-------Set接口：存储无序，不可重复的元素.Set中常用的方法都是Collection下定义的
 *               |--------HashSet(主要的实现类)
 *               |--------LinkedHashSet,
 *               |--------TreeSet
 */
public class TestSet {

	/*
	 * LinkedHashSet:使用链表维护了一个添加进集合中的顺序，导致我们遍历LinkedHashSet集合
	 * 元素时，是按照添加进去的顺序遍历的！
	 * 
	 * LinkedHashSet插入性能略低于HashSet，但在迭代访问Set里的全部元素时由很好的性能
	 */
	
	//遍历出来的顺序与添加顺序相同
	@Test
	public void testLinkedHashSet() {
		Set set = new LinkedHashSet();
		set.add(456);
		set.add(123);
		set.add(new String("AA"));
		set.add(new String("AA"));
		set.add(new String("BB"));
        set.add("BB");
        set.add(null);
        
        Iterator i = set.iterator();
        while(i.hasNext()) {
        	System.out.print(i.next()+", ");  //456, 123, AA, BB, null, 
        }
	}
	
	
	
	/*
	 * Set:存储的元素是无序的(指的是元素在底层存放的位置无序)，不可重复的！
	 * 1. 无序性 != 随机性
	 * 2. 不可重复性：当向Set中添加相同的元素的时候，后面的这个不能添加进去
	 *
	 * 说明：要求添加进Set中的元素所在的类，一定要重写equals（）和hashCode（）方法。
	 * 进而保证Set中元素的不可重复性
	 * 
	 * Set中元素是如何存储的呢？使用了哈希算法。 
	 * 当向Set中添加对象时，首先调用此对象所在类的hashCode()方法，计算此对象的哈希值，此哈希值
	 * 决定了此对象在Set中的存储位置。若此位置之前没有对象存储，则这个对象直接存储到此位置，若此位置
	 * 已有对象存储，再通过equals方法比较这两个对象是否相同，如果相同，后一个对象就不能添加进来
	 * 
	 * 万一返回false呢，都存储（不建议如此）
	 * >要求：hashCode()方法要与equals()方法一致。
	 */
	
	
	
	//遍历出来的顺序与添加顺序不同
	@Test
	public void testHashSet() {
		Set set = new HashSet();
		set.add(123);
		set.add(456);
		set.add("AA");
		set.add("BB");
		set.add(null);
		Person p1 = new Person("GG", 23);
		Person p2 = new Person("GG", 23);
        System.out.println(p1.equals(p2));//true；因为Person类中重写了equals方法，所以此处为true
		System.out.println(p1.hashCode());//3946;因为Person类中重写了hashCode方法，所以此处p1和p2的hashCode相等
		System.out.println(p2.hashCode());//3946

        //因为set不可重复性，所以向set中添加元素时，首先调用此对象所在类的hashCode()方法（即p1,p2所在的Person类中重写的equals方法），计算此对象的哈希值，此哈希值
		//决定了此对象在Set中的存储位置。若此位置之前没有对象存储，则这个对象直接存储到此位置，若此位置
		//已有对象存储，再通过此对象所在类的equals方法比较这两个对象是否相同，如果相同，后一个对象就不能添加进来
        set.add(p1);
        set.add(p2);
		System.out.println(set.size());//6,如果Person类中没有重写hashCode方法和equals方法则结果为7
		System.out.println(set);//如果Person类中重写了hashCode方法则结果为：[AA, BB, null, 456, Person [name=GG, age=23], 123]，否则结果为[AA, BB, null, Person [name=GG, age=23], 456, 123, Person [name=GG, age=23]]
	}
}
