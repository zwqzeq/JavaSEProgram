package com.zwq;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

import org.junit.Test;

/*
 * 1. 存储对象可以考虑：①数组，②集合
 * 2. 数组存储对象的特点：Student[] stu = new Student[20];  stu[0]=new Student();.....
 * > 弊端：①一旦创建，其长度不可变.②真实的数组存放的对象的个数是不可知的
 * 3. 集合
 *     Collection接口
 *          |-------List接口：存储有序，可重复的元素
 *                |--------Vector(古老的实现类，线程安全的，但效率低于ArrayList)，
 *                |--------ArrayList(主要的实现类)
 *                |--------LinkedList(对于频繁的插入，删除操作)
 *
 *          |-------Set接口：存储无序，不可重复的元素,Set中常用的方法都是Collection下定义的
 *                |--------HashSet(主要的实现类)
 *                |--------LinkedHashSet
 *                |--------TreeSet
 *     Map接口：存储“键-值”对的数据   
 *          |-------HashMap，
 *          |-------LinkedHashMap，
 *          |-------TreeMap，
 *          |-------HashTable（子类Properties）       
 */        
public class TestCollection {
	
	@Test
	public void testCollection3() {
		Collection coll = new ArrayList();
		coll.add(123);
		coll.add("AA");
		coll.add(new Date());
		coll.add("BB");
		coll.add(new Person("MM", 23));
		
		Collection coll1 = new ArrayList();
		coll1.add(123);
		coll1.add(new String("AA"));
		//10.removeAll(Collection coll)：从当前集合中移除与集合coll集合中相同元素
        coll.removeAll(coll1);
        System.out.println(coll);      //[Fri Aug 17 13:09:45 CST 2018, BB, Person [name=MM, age=23]]
	    //11.equals(Object obj)：判断集合中的所有元素是否完全相同
	    Collection coll2 = new ArrayList();
	    coll2.add(123);
	    coll2.add(new String("AA"));
	    System.out.println(coll1.equals(coll2));//true
	    //12.hashCode()
	    System.out.println(coll.hashCode());   //-601828221
	    //13.toArray():将集合转化为数组
	    System.out.println("===============");
	    Object[] obj = coll.toArray();
	    for (int i = 0; i < obj.length; i++) {
			System.out.println(obj[i]);			
		}
	    //14.iterator():返回一个iterator接口实现类的对象
	    System.out.println();
	    Iterator iterator = coll.iterator();
	    /*
	     * 方式一：不用
	     * System.out.println(iterator.next());
	     * System.out.println(iterator.next());
	     * System.out.println(iterator.next());
	     * 
	     * 方式二：不用
	     *  for (int i = 0; i < coll.size(); i++) {
		 *	System.out.println(iterator.next());
		 *  }
	     * 
	     */ 
	    //方式三：使用
	    while(iterator.hasNext()) {
	    	System.out.println(iterator.next());
	    }
	   
	
	}
	
	
	
	
	@Test
	public void testCollection2() {
		Collection coll = new ArrayList();
		coll.add(123);
		coll.add("AA");
		coll.add(new Date());
		coll.add("BB");
		//Person p = new Person("MM", 23);
		coll.add(new Person("MM", 23));
		System.out.println(coll);//[123, AA, Thu Aug 16 13:53:18 CST 2018, BB, Person [name=MM, age=23]]

		//6.contains(Object obj):判断集合中是否包含指定的obj元素。如果包含返回true，反之，返回false
		//判断依据：根据元素所在的类的equals()方法进行判断
		//明确：如果存入集合中的元素是自定义类的对象。要求：自定义类要重写equals()方法。
		boolean b1 = coll.contains(123);
		b1 = coll.contains("AA");
		System.out.println(b1);//true;因为String类重写了equals方法
		boolean b2 = coll.contains(new Person("MM", 23));
		System.out.println(b2);//true;因为Person类中重写了equals方法
		//7.containsAll(Collection coll)//判断当前集合中是否包含coll中所有元素
		Collection coll1 = new ArrayList();
		coll1.add(123);
		coll1.add(new String("AA"));
		boolean b3 = coll.containsAll(coll1);
		//8.retainAll(Collection coll)//求当前集合与coll的共有的元素(求交集)，返回给当前集合
		boolean bb = coll.retainAll(coll1);
		System.out.println(bb);//true；交集不为空
		System.out.println(coll);//交集为：【123，AA】
		//9.remove(Object obj):删除集合中的obj元素，若删除成功，返回true
		boolean b4 = coll.remove("BB");//coll中只含有【123，AA】没有BB，所以删除BB失败，返回false
		System.out.println(b4);//false
		
	}
	
	
	
	@Test
	public void testCollection1() {
		Collection coll = new ArrayList();
		//1. size():返回集合中元素个数
		System.out.println(coll.size());     //0
		//2. add(Object obj):向集合中添加一个元素
		coll.add(123);
		coll.add("AA");
		coll.add(new Date());
		coll.add("BB");
		System.out.println(coll.size());	 //4
	    //3.addAll(Collection coll):将形参coll中包含的所有元素添加到当前集合中
	    /*Arrays.asList()该方法是将数组转化为list。有以下几点需要注意：
		 *　（1）该方法不适用于基本数据类型（byte,short,int,long,float,double,boolean）
		 *
		 *　（2）该方法将数组与列表链接起来，当更新其中之一时，另一个自动更新
		 *
		 *　（3）不支持add和remove方法
		 *
		 * public static void main(String[] args) {
         * String[] s = {"aa","bb","cc"};
         * List<String> strlist = Arrays.asList(s);
         * for(String str:strlist){
         *   System.out.println(str);
         * }
         *System.out.println("------------------------");
         *基本数据类型结果打印为一个元素
         * int[] i ={11,22,33}; 
         *List intlist = Arrays.asList(i);
         *for(Object o:intlist){
         *   System.out.println(o.toString());
         *}
         *System.out.println("------------------------");
         *Integer[] ob = {11,22,33};
         *List<Integer> oblist = Arrays.asList(ob);
         *for(int a:oblist){
         *   System.out.println(a);
         *}
         *System.out.println("------------------------");
         *}
         *}
		 *运行结果：
		 *aa
		 *bb
		 *cc
		 *----------------
		 *[I@2524e205
		 *---------分割线----------
		 *11
		 *22
		 *33
		 *--------------------
		 */
		Collection coll1 = Arrays.asList(1,2,3,"AA",new String("CC")); 
	    coll.addAll(coll1);
		System.out.println(coll.size());     //9
		//4. isEmpty():判断集合是否为空
		System.out.println(coll.isEmpty());  //false
		// 5. clear():清空集合元素
		coll.clear();
		System.out.println(coll.isEmpty());  //true
	}
}
