package com.zwq;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class TestList {
	
	//ArrayList:List接口的主要实现类
	/*
	 * List中相对于Collection，新增加的方法
	 * void add(int index,Object obj):在指定的索引位置index处添加元素
	 * boolean addAll(int index,)
	 * Object get(int index):获取指定索引位置元素
	 * int indexOf(Object obj):返回obj在集合中首次出现的位置，没有的话返回-1
	 * int lastIndexOf(Object obj):返回obj在集合中最后一次出现的位置，没有的话返回-1
	 * Object remove(int index)：删除指定索引位置的元素
	 * Object set(int index,Object ele)//设置指定索引位置的元素为ele
	 * List subList(int fromIndex,int toIndex)：返回从fromIndex到toIndex结束的一个子list,左闭右开
	 * 
	 * List常用的方法：增（add(Object obj)）,删(remove),改(set(int index,Object obj)),查(get(int index)),插(add(int index,Object obj)),长度(size())
	 */
	
	
	@Test
	public void test2() {
		List list = new ArrayList();
		list.add(123);
		list.add(456);
		list.add(new String("AA"));
	    list.add(new String("GG"));
	    list.add(456);
	    System.out.println(list.indexOf(456));//1
	    System.out.println(list.lastIndexOf(456));//4
	    System.out.println(list.indexOf(123) == list.lastIndexOf(123));//true
	    System.out.println(list.indexOf(444));//-1
	    
	    List list1 = list.subList(0, 3);
	    System.out.println(list1);        //[123, 456, AA]

	}
	
	
	@Test
	public void test1() {
		List list = new ArrayList();
		list.add(123);
		list.add(456);
		list.add(new String("AA"));
	    list.add(new String("GG"));
	    
	    System.out.println(list);//[123, 456, AA, GG]
	    list.add(0,555);//在下标为零的位置插入
	    System.out.println(list);//[555, 123, 456, AA, GG]
	    Object obj = list.get(1);
	    System.out.println(obj);//123
	    list.remove(0);//移除下标为零的元素（即移除555）
	    System.out.println(list.get(0));//123
	    list.set(0, 111);
	    System.out.println(list.get(0));//111
	}
}
