package com.zwq;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

import org.junit.Test;

public class TestIterator {

	// 面试题
	@Test
	public void test5() {
		String[] str = new String[] { "AA", "BB", "DD" };
		//表示每次从str中取出一个元素赋给局部变量s，所以s值的修改，并不影响str中的值
		for (String s:str) {
			s = "MM";
			System.out.println(s);
		}

		for (int i = 0; i < str.length; i++) {
			System.out.println(str[i]);
		}
	}
	//***********************************************
	// 使用增强for循环实现数组的遍历
	@Test
	public void test4() {
		String[] str = new String[] { "AA", "BB", "DD" };
		for (String s : str) {
			System.out.println(s);
		}

	}

	// 使用增强for循环实现集合的遍历
	@Test
	public void test3() {
		Collection coll = new ArrayList();
		coll.add(123);
		coll.add("AA");
		coll.add(new Date());
		coll.add("BB");
		coll.add(new Person("MM", 23));

		for (Object o : coll) {
			System.out.println(o);
		}

	}

	// 错误的写法
	@Test
	public void test2() {
		Collection coll = new ArrayList();
		coll.add(123);
		coll.add("AA");
		coll.add(new Date());
		coll.add("BB");
		coll.add(new Person("MM", 23));

		Iterator i = coll.iterator();
		while (i.next() != null) {
			// java.util.NoSuchElementException
			System.out.println(i.next());
		}
	}

	// 正确的写法：使用迭代器Iterator实现集合的遍历
	@Test
	public void test1() {
		Collection coll = new ArrayList();
		coll.add(123);
		coll.add("AA");
		coll.add(new Date());
		coll.add("BB");
		coll.add(new Person("MM", 23));
		Iterator i = coll.iterator();
		while (i.hasNext()) {
			System.out.println(i.next());
		}
	}

}
