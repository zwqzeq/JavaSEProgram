package com.zwq;

import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

import org.junit.Test;

/*Collection接口
*          |-------List接口：存储有序，可重复的元素
*               |--------Vector(古老的实现类，线程安全的，但效率低于ArrayList)，
*               |--------ArrayList(主要的实现类),
*               |--------LinkedList(对于频繁的插入，删除操作)
*
*          |-------Set接口：存储无序，不可重复的元素.Set中常用的方法都是Collection下定义的
*               |--------HashSet(主要的实现类)
*               |--------LinkedHashSet,
*               |--------TreeSet
*               
*/


public class TestTreeSet {
	
	/*
	 * TreeSet的定制排序
	 *  见下面的步骤
	 *  compare()与hashCode()以及equals()三者保持一致！ 
	 * 
	 */
	@Test
	public void testTreeSet2() {
		// 1.创建一个实现了Comparator接口的类对象
		Comparator com = new Comparator() {

			
			//向TreeSet中添加Customer类的对象，在此compare()方法中，指明是按照Customer的哪个属性排序的
			@Override
			public int compare(Object o1, Object o2) {
				// TODO 自动生成的方法存根
				if(o1 instanceof Customer && o2 instanceof Customer) {
					Customer c1 = (Customer) o1;
					Customer c2 = (Customer) o2;
				//	return c1.getId().compareTo(c2.getId());
				int i = c1.getId().compareTo(c2.getId());
					
				//这种方式，返回结果为[name=CC, id=1001], [name=DD, id=1001], [name=BB, id=1002], [name=AA, id=1003], [name=GG, id=1004]
				if (i == 0) {     //如果id相同
						return c1.getName().compareTo(c2.getName());//接着比较姓名
					}

					//id不同
					return i; //即return c1.getId().compareTo(c2.getId())且值为-1或者1
				}
				
				
	/*	
				// 这种方式，返回结果为 [name=DD, id=1001], [name=BB, id=1002], [name=AA, id=1003], [name=GG, id=1004]
				if(c1.getId()!=c2.getId()) {
					return i; //即return c1.getId().compareTo(c2.getId())且值为-1或者1
				} else {
					
					return c1.getName().compareTo(c2.getName());
				}
				
			}
	*/
				//o1或o2不是Customer类的对象
				return 0;
			}
		};
		
		//2. 将此对象作为形参传递给TreeSet的构造器
		TreeSet set = new TreeSet(com);
		//3. 向TreeSet中添加Comparator接口中的compare方法中涉及的类的对象。
		set.add(new Customer("AA",1003));
		set.add(new Customer("BB",1002));
		set.add(new Customer("GG",1004));
		set.add(new Customer("DD",1001));
		set.add(new Customer("CC",1001));
        
		for (Object str:set) {
			System.out.println(str);
		}
	
	}
	

	
	/*
	 * TreeSet:
	 * 1. 向TreeSet中添加的元素必须是同一个类的
	 * 2. 可以按照添加进集合中的元素的指定的顺序遍历，像String,包装类等默认按照从小到大顺序遍历
	 * 3. 当向TreeSet中添加自定义类的对象时，有两种排序方法：①自然排序②定制排序
	 * 4. 自然排序：要求自定义类实现java.lang.Comparable接口并重写其compareTo(Object o)
	 * 在此方法中，指明按照自定义类的哪个属性进行排序。
	 * 
	 * 5. 向TreeSet中添加的元素时，首先按照compareTo()进行比较，一旦返回0，虽然仅是两个对象的此
	 * 属性组相同，但是程序会认为这两个对象相同，进而后一个对象不能添加进来
	 * 
	 * >compareTo()与hashCode()以及equals()三者保持一致！
	 */
	@Test
	public void testTreeSet1() {
		Set set = new TreeSet();
//		set.add(new String("AA"));
//		set.add(new String("AA"));
//		set.add(new String("BB"));
//		set.add(123);
//		set.add(456);
		
//		set.add("JJ");
//		set.add("GG");
//		set.add("MM");
		
		//当Person类没有实现Comparable
		set.add(new Person("CC", 23));
		set.add(new Person("MM", 21));
		set.add(new Person("GG", 25));
		set.add(new Person("JJ", 24));
		set.add(new Person("DD", 20));
		//5. 向TreeSet中添加的元素时，首先按照compareTo()进行比较，一旦返回0，虽然仅是两个对象的此
		// 属性组相同，但是程序会认为这两个对象相同，进而后一个对象不能添加进来
		set.add(new Person("KK", 20));

		for (Object str:set) {
			System.out.println(str);
		}
	}
}
