package com.interview;

import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.TreeSet;

import org.junit.Test;

/*
 * 创建该类的5个对象，并把这些对象放入TreeSet集合中（下一章：TreeSet需要使用泛型来定义）
 * 分别按照以下两种方式对集合中的元素进行排顺序，并遍历输出
 * 
 * 1).Employee实现Comparable接口，并按照name排序
 * 
 * 2).创建TreeSet时传入Comparator对象，按照生日日期先后排序
 * 
 * 提示：Employee类是否需要重写equals()方法？MyDate类呢？
 * 
 * 
 * 
 * 
 */
public class TestEmployee {
	
	//定制排序：创建TreeSet时传入Comparator对象，按照生日日期的先后顺序
	@Test
	public void test2() {
		Comparator com = new Comparator() {

			@Override
			public int compare(Object o1, Object o2) {
				if (o1 instanceof Employee1 && o2 instanceof Employee1) {
					Employee1 e1 = (Employee1) o1;
					Employee1 e2 = (Employee1) o2;
					MyDate birth1 = e1.getBirthday();
					MyDate birth2 = e2.getBirthday();
					if (birth1.getYear() != birth2.getYear()) {//年不相等
						return birth1.getYear() - birth2.getYear();
					} else {//年相等
						if (birth1.getMonth() != birth2.getMonth()) {//年相等，月不等
							return birth1.getMonth() - birth2.getMonth();
						} else {//年相等，月相等，日不相等
							return birth1.getDay()-birth2.getDay();
						}
					}
				}
				//o1,或者o2不是Employee1类的对象
				return 0;
			}
		}; 
		TreeSet set = new TreeSet(com);
		Employee1 e1 = new Employee1("刘德华",55,new MyDate(4,12,1976));
		Employee1 e2 = new Employee1("郭富城",43,new MyDate(7,3,1954));
		Employee1 e3 = new Employee1("张学友",33,new MyDate(9,12,1954));
		Employee1 e4 = new Employee1("黎明",54,new MyDate(12,3,1954));
		Employee1 e5 = new Employee1("李敏镐",65,new MyDate(4,21,1945));
		set.add(e1);
		set.add(e2);
		set.add(e3);
		set.add(e4);
		set.add(e5);

		Iterator iterator = set.iterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}
	}
	
	
	
	
	
	
	
	//自然排序：使Employee实现Comparable接口，并按name排序
	@Test
	public void test1() {
		Employee e1 = new Employee("刘德华",55,new MyDate(4,12,1976));
		Employee e2 = new Employee("郭富城",43,new MyDate(7,3,1965));
		Employee e3 = new Employee("张学友",33,new MyDate(9,12,1954));
		Employee e4 = new Employee("黎明",54,new MyDate(12,2,1967));
		Employee e5 = new Employee("李敏镐",65,new MyDate(4,21,1945));
		//因为是按照姓名排序，所以进不去
		//Employee e6 = new Employee("李敏镐",63,new MyDate(4,21,1945));

		
		TreeSet set = new TreeSet();
	    set.add(e1);
	    set.add(e2);
	    set.add(e3);
	    set.add(e4);
	    set.add(e5);
	    
	    Iterator iterator = set.iterator();
	    while (iterator.hasNext()) {
	    	System.out.println(iterator.next());
	    }
	
	}
}
