package com.interview;

import static org.hamcrest.CoreMatchers.nullValue;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/*
 * 
 */
public class MyInput {
	
	public String nextString() {
		InputStreamReader isr = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(isr);
		String str = null;
		try {
			str = br.readLine();
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		return str;
		
	}
	
	public int nextInt() {
		return Integer.parseInt(nextString());
	}
	
	public boolean nextBoolean() {
		return Boolean.parseBoolean(nextString());
	}
	
	public static void main(String[] args) {
		MyInput input = new MyInput();
		System.out.println("请输入一个字符串：");
		String str = input.nextString();
		System.out.println(str);
		
		int j = input.nextInt();
		System.out.println(j + 1);
		
		
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
}
