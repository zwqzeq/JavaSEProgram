package com.zwq;

import static org.hamcrest.CoreMatchers.nullValue;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import org.junit.Test;

/*
 * 
 * 1. 流的分类：
 * 按照数据流向的不同：输入流，输出流
 * 按照处理数据的单位不同：字节流，字符流（处理的文本文件）
 * 按照角色不同：节点流（直接作用于文件的），处理流（）包装在已有的节点流之上
 * 
 * 
 * IO的体系：
 * 抽象基类		          节点流（文件流）                       缓冲流（处理流的一种,可以提升文件操作的效率）            
 * 字节流
 * InputStream      FileInputStream      BufferedInputStream
 * OutputStream     FileOutputStream     BufferedOutputStream
 * 
 * 字符流
 * Reader        	FileReader           BufferedReader 
 * Writer		    FileWriter           BufferedWriter
 */
public class TestBuffered {

	@Test
	public void testBufferedReader() {
		BufferedReader br = null;
		BufferedWriter bw = null;
		try {
			File file = new File("hello1.txt");
			File file1 = new File("hello4.txt");
			FileReader fr = new FileReader(file);
			FileWriter fw = new FileWriter(file1);
			br = new BufferedReader(fr);
			bw = new BufferedWriter(fw);
			//方式一：
//			char[] c = new char[1024];
//			int len;
//			while((len = br.read(c)) != -1) {
//				String str = new String(c,0,len);
//				System.out.print(str);
//			}
			
			//方式二：
			String str;
			while((str = br.readLine()) != null) {
				//System.out.println(str);
				bw.write(str);//没有自动换行，导致复制的文件内容在一行
				bw.newLine(); //换行
				bw.flush();
			}
			
			
			
		} catch (FileNotFoundException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} finally {
			    if (bw != null) {
			    	try {
						bw.close();
					} catch (IOException e) {
						// TODO 自动生成的 catch 块
						e.printStackTrace();
					}	
			    }
			
				if (br != null) {
					try {
						br.close();
					} catch (IOException e) {
						// TODO 自动生成的 catch 块
						e.printStackTrace();
					}					
				}	
		}
	}
	
	
	
	
	
	
	
	
	
	
	@Test
	public void testCopyFile() {
		long start = System.currentTimeMillis();
		String src = "C:\\Users\\shkstart\\Desktop\\1.avi";
		String dest = "C:\\Users\\shkstart\\Desktop\\2.avi";
		copyFile(src, dest);
		long end = System.currentTimeMillis();
		System.out.println("花费的时间为："+ (end - start));
	}
	
	//使用缓冲流实现文件的复制的方法
	public void copyFile(String src,String dest) {
		// 3.将创建的节点流的对象作为形参传递给缓冲流的构造器中
				BufferedInputStream bis = null;
				BufferedOutputStream bos = null;
				try {
					// 1. 提供读入，写出的文件
					File file1 = new File(src);
					File file2 = new File(dest);
					// 2. 先创建相应的结点流：FileInputStream，FileOutputStream
					FileInputStream fis = new FileInputStream(file1);
					FileOutputStream fos = new FileOutputStream(file2);
					
					bis = new BufferedInputStream(fis);
					bos = new BufferedOutputStream(fos);
					
					// 4.具体的实现文件复制的操作
					byte[] b = new byte[1024];
					int len;
					while((len = bis.read(b)) != -1) {
						bos.write(b, 0, len);
						bos.flush();
					}
				} catch (FileNotFoundException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				} finally {
					// 5.关闭相应的流
					if (bos != null) {
						try {
							bos.close();
						} catch (IOException e) {
							// TODO 自动生成的 catch 块
							e.printStackTrace();
						}
					}
					if (bis != null) {
						try {
							bis.close();
						} catch (IOException e) {
							// TODO 自动生成的 catch 块
							e.printStackTrace();
						}
					}
					
				}
	}
	
	
	
	
	
	
	//使用BufferedInputStream和BufferedOutputStream实现非文本文件的复制
	@Test
	public void testBufferedInputOutputStream() {
		// 3.将创建的节点流的对象作为形参传递给缓冲流的构造器中
		BufferedInputStream bis = null;
		BufferedOutputStream bos = null;
		try {
			// 1. 提供读入，写出的文件
			File file1 = new File("C:\\Users\\shkstart\\Desktop\\1.jpg");
			File file2 = new File("C:\\Users\\shkstart\\Desktop\\2.jpg");
			// 2. 先创建相应的结点流：FileInputStream，FileOutputStream
			FileInputStream fis = new FileInputStream(file1);
			FileOutputStream fos = new FileOutputStream(file2);
			
			bis = new BufferedInputStream(fis);
			bos = new BufferedOutputStream(fos);
			
			// 4.具体的实现文件复制的操作
			byte[] b = new byte[1024];
			int len;
			while((len = bis.read(b)) != -1) {
				bos.write(b, 0, len);
				bos.flush();
			}
		} catch (FileNotFoundException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} finally {
			// 5.关闭相应的流
			if (bos != null) {
				try {
					bos.close();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}
			}
			if (bis != null) {
				try {
					bis.close();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}
			}
			
		}
	}
	
	
	
	
	
	
	
	
	
	
}
