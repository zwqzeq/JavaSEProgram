package com.zwq;

import static org.hamcrest.CoreMatchers.nullValue;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.junit.Test;

/*
 * 
 * 1. 流的分类：
 * 按照数据流向的不同：输入流，输出流
 * 按照处理数据的单位不同：字节流，字符流（处理的文本文件）
 * 按照角色不同：节点流（直接作用于文件的），处理流（包装在已有的节点流之上）
 * 
 * 
 * IO的体系：
 * 抽象基类		          节点流（文件流）                       缓冲流（处理流的一种）            
 * 字节流
 * InputStream      FileInputStream      BufferedInputStream
 * OutputStream     FileOutputStream     BufferedOutputStream
 * 
 * 字符流
 * Reader        	FileReader           BufferedReader 
 * Writer		    FileWriter           BufferedWriter
 */
public class TestInputOutputStream {
	
	//实现文件复制的方法
	public static void copyFile(String src,String desc) {
		//1. 提供读入，写出的文件
				File file1 = new  File(src);
				File file2 = new  File(desc);
				
				//2.提供相应的流
				FileInputStream fis = null;
				FileOutputStream fos = null;

				try {
					fis = new FileInputStream(file1);
					fos = new FileOutputStream(file2);
					//3.实现文件的复制
					byte[] b = new byte[20];
					int len;
					while((len = fis.read(b)) != -1) {
						//错误的写法两种：fos.write(b);或者fos.write(b,0,b.length);
						
						//正确的写法
						fos.write(b, 0, len);
					}
				} catch (FileNotFoundException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				} finally {
					if(fos != null) {
						try {
							fos.close();
						} catch (IOException e) {
							// TODO 自动生成的 catch 块
							e.printStackTrace();
						}
					}
					
					if (fis!=null) {
						try {
							fis.close();
						} catch (IOException e) {
							// TODO 自动生成的 catch 块
							e.printStackTrace();
						}
					}
				}
	}
	
	
	
	
	
	
	//从硬盘读取一个文件，并写入到另一个位置
	@Test
	public void testInputOutputStream() {
		//1. 提供读入，写出的文件
		File file1 = new  File("hello.txt");
		File file2 = new  File("hello3.txt");
		
		//2.提供相应的流
		FileInputStream fis = null;
		FileOutputStream fos = null;

		try {
			fis = new FileInputStream(file1);
			fos = new FileOutputStream(file2);
			//3.实现文件的复制
			byte[] b = new byte[20];
			int len;
			while((len = fis.read(b)) != -1) {
				//错误的写法两种：fos.write(b);或者fos.write(b,0,b.length);
				
				//正确的写法
				fos.write(b, 0, len);
			}
		} catch (FileNotFoundException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} finally {
			if(fos != null) {
				try {
					fos.close();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}
			}
			
			if (fis!=null) {
				try {
					fis.close();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}
			}
			
		}
}
		

	
	
	
	
	
	
	
	//FileOutputStream
	@Test
	public void testOutputStream1() {
		FileOutputStream fos = null;
		try {
			//1.创建一个File对象，表明要写入的文件的位置
			//输出的物理文件可以不存在，当执行的过程中，若不存在会自动创建，若存在，会将原有的文件覆盖
			File file = new File("hello2.txt");
			fos = null;
			//2.创建一个FileOutputStream的对象，将file的对象作为形参传递给FileOutputStream的构造器中
			fos = new FileOutputStream(file);
			//3.写入的操作
			fos.write(new String("I love China I love the world!").getBytes());
		} catch (FileNotFoundException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} finally {
			//4.关闭输出流
			if (fos != null) {
				try {
					fos.close();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}
				
			}
		}
	}
	
	
	
	
	
	
	
	
	@Test
	public void testFileInputStream3() {
		FileInputStream fis = null;
		try {
			File file = new File("hello.txt");
			fis = new FileInputStream(file);
			byte[] b = new byte[5];//读取到的数据要写入的数组
			int len;//每次读入到byte中的字节的长度
			while((len = fis.read(b)) != -1) {

				//方式一：
//				for (int i = 0; i < len; i++) {//不能写成 i < b.length
//					System.out.print((char)b[i]);
//					
//				}
				
				//方式二：
				String str = new String(b,0,len);
				System.out.print(str);
				
			}
		}catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} finally {
			try {
				if (fis != null) {
					fis.close();
					
				}
			} catch (IOException e) {
				// TODO 自动生成的 catch 块
				e.printStackTrace();
			}
			
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	//使用try-catch的方式处理如下的异常更合理:保证流的关闭操作一定能够执行
	@Test
	public void testFileInputStream2() {
		// 2.创建一个FileInputStream类的对象
		FileInputStream fis =null;
		try {
			// 1.创建一个File类的对象
			File file = new File("hello.txt");
			fis = new FileInputStream(file);
			// 3.调用FileInputStream类的方法，实现file文件的读取
           /*
			* read():读取文件的一个字节。
			*/
			int b = fis.read();
			while(b!=-1) {
				System.out.println((char)b);
				b=fis.read();
			}
		} catch (FileNotFoundException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} finally {			
			// 4.关闭相应的流
			try {
				if (fis != null) {
					fis.close();
					
				}
			} catch (IOException e) {
				// TODO 自动生成的 catch 块
				e.printStackTrace();
			}
		}
	}
	
	
	
	
	
	
	
	
	//从硬盘存在的一个文件中，读取其内容到程序中。使用FileInputStream
	//要读取的文件一定要存在，否则抛FileNotFoundException
	@Test
	public void testFileInputStream() throws IOException {
		// 1.创建一个File类的对象
		File file = new File("hello.txt");
		// 2.创建一个FileInputStream类的对象
	    FileInputStream fis = new FileInputStream(file);
	    // 3.调用FileInputStream类的方法，实现file文件的读取
	   /*
	    * read():读取文件的一个字节。
	    */
	    int b = fis.read();
	    while(b!=-1) {
	    	System.out.println((char)b);
	    	b=fis.read();
	    }
	    // 4.关闭相应的流
	    fis.close();
	}
}
