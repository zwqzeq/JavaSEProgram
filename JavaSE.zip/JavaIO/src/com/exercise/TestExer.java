package com.exercise;

import static org.hamcrest.CoreMatchers.anything;
import static org.hamcrest.CoreMatchers.nullValue;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import org.junit.Test;

public class TestExer {

	//字符流复制test.txt为test1.txt
	@Test
	public void test4() {
		BufferedReader br = null;
		BufferedWriter bw = null;
		
		try {
			br=new BufferedReader(new FileReader(new File("text.txt")));
			bw = new BufferedWriter(new FileWriter(new File("test2.txt")));
			char[] c = new char[20];
			int len;
			while((len = br.read(c)) != -1) {
				bw.write(c,0,len);
			}
		} catch (FileNotFoundException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} finally {
			if (bw != null) {
				try {
					bw.close();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}
				
			}
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}
				
			}
			
		}

	}
	
	
	
	
	//使用字符流实现内容的读入
	@Test
	public void test3() {
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader("test.txt"));
			String str;
			while((str = br.readLine())!=null) {
				System.out.println(str);
			}
		} catch (FileNotFoundException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		if(br != null) {
			try {
				br.close();
			} catch (IOException e) {
				// TODO 自动生成的 catch 块
				e.printStackTrace();
			}
			
		}
	}
	
	
	
	//使用字符流实现内容的输出
	@Test
	public void test2() {
		BufferedWriter bw = null;
		try {
			bw = new BufferedWriter(new FileWriter("test1.txt"));
			String str = "Java是一种可以撰写跨平台应用软件的面向对象的程序设计语言，\n"
					+ "java虚拟机(Java Virtual Machine) 简称JVM \n "
					+ "Java语言写的代码是.java文件，它会被特定程序编\n"
					+ "译(javac.exe，它会被Eclipse之类的IDE调用)成\n"
					+ "字节码(bytecode)，字节码不能直接在CPU上运行，需要另一个程序"
					+ "读取并执行，这个部件就是java虚拟机，它像机器一样运行编译好的java字"
					+ "节码，就像机器直接执行机器码一样……java虚拟机的外部接口在windows下主"
					+ "要是jvm.dll这个文件";
			bw.write(str);
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} finally {
			if(bw != null){
				try {
					bw.close();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}
				
			}
		}
	}
	
	//使用字节流实现内容的输出
	@Test
	public void test1() {
		//FileOutputStream fos = new FileOutputStream(new File("test.txt"));
		//BufferedOutputStream bos = new BufferedOutputStream(fos);
		BufferedOutputStream bos = null;
		try {
			bos = null;
			bos = new BufferedOutputStream(
					new FileOutputStream(new File("text.txt")));
			String str = "Java是一种可以撰写跨平台应用软件的面向对象的程序设计语言，\n"
					+ "java虚拟机(Java Virtual Machine) 简称JVM \n "
					+ "Java语言写的代码是.java文件，它会被特定程序编\n"
					+ "译(javac.exe，它会被Eclipse之类的IDE调用)成\n"
					+ "字节码(bytecode)，字节码不能直接在CPU上运行，需要另一个程序"
					+ "读取并执行，这个部件就是java虚拟机，它像机器一样运行编译好的java字"
					+ "节码，就像机器直接执行机器码一样……java虚拟机的外部接口在windows下主"
					+ "要是jvm.dll这个文件";
			
			bos.write(str.getBytes());
		} catch (FileNotFoundException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} finally {
			if (bos!=null) {
				try {
					bos.close();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}
				
			}
		}

	}
}
