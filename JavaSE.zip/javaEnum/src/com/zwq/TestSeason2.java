package com.zwq;

import com.zwq.TestSeason.Season;

/*
 * 一：枚举类
 * 1.如何自定义枚举类
 * 2.如何使用enum关键字定义枚举类
 * >常用的方法:values() valueOf(String name)
 * >如何让枚举类实现接口：可以让不同的枚举类的对象调用被重写的抽象方法，执行的效果不同。（相当于让每个对象重写抽象方法）
 */
public class TestSeason2 {

	public static void main(String[] args) {
		Season2 spring = Season2.SPRING;
		System.out.println(spring);
		spring.show();
		System.out.println(spring.getSeason2Name());
		System.out.println();
		// 1. values()
		Season2[] season2s = Season2.values();
		for (int i = 0; i < season2s.length; i++) {
			System.out.println(season2s[i]);
		}

		// 2. valueOf(String name):要求传入的形参name是枚举对象的名字，否则报异常
		String str = "SPRING";
		Season2 sea = Season2.valueOf(str);
		System.out.println(sea);

		System.out.println();

		// Thread类中的内部类State就是一个枚举类
		Thread.State[] states = Thread.State.values();
		for (int i = 0; i < states.length; i++) {
			System.out.println(states[i]);
		}

	}

	interface Info {
		void show();
	}

	/*
	 * // 枚举类 enum Season2 implements Info { 
	 * SPRING("spring", "春暖花开") { 
	 *     public void show() { 
	 *     System.out.println("春天在哪里？"); 
	 *     }
	 * }, 
	 * SUMMER("summer", "夏日炎炎"){ 
	 *     public void show() {
	 *     System.out.println("生如夏花"); 
	 *     } 
	 * }, 
	 * AUTUMN("autumn", "秋高气爽") { 
	 *     public void show() { 
	 *         System.out.println("秋天来了"); 
	 *         } 
	 * }, 
	 * WINTER("winter", "白雪皑皑") {
	 *      public void show() { 
	 *           System.out.println("冬天里的一把火"); 
	 *           } 
	 * };
	 * 
	 * private final String Season2Name; 
	 * private final String Season2Desc;
	 * 
	 * private Season2(String Season2Name, String Season2Desc) {
	 * this.Season2Name = Season2Name; 
	 * this.Season2Desc = Season2Desc; 
	 * }
	 * 
	 * public String getSeason2Name() { 
	 *     return Season2Name; 
	 * }
	 * 
	 * public String getSeason2Desc() {
	 *      return Season2Desc; 
	 * }
	 * 
	 * @Override public String toString() { 
	 *      return "Season2 [Season2Name=" + Season2Name + ", Season2Desc=" + Season2Desc + "]"; 
	 * }
	 */

	// 枚举类
	enum Season2 {
		//必须放在最上面
		//相当于public static final Season SPRING = new Season("spring", "春暖花开");
		SPRING("spring", "春暖花开"), 
		SUMMER("summer", "夏日炎炎"),
		AUTUMN("autumn", "秋高气爽"), 
		WINTER("winter", "白雪皑皑");
		
		private final String Season2Name;
		private final String Season2Desc;

		/**
		 * 构造器
		 * @param Season2Name
		 * @param Season2Desc
		 */
		private Season2(String Season2Name, String Season2Desc) {
			this.Season2Name = Season2Name;
			this.Season2Desc = Season2Desc;
		}
		public String getSeason2Name() {
			return Season2Name;
		}

		public String getSeason2Desc() {
			return Season2Desc;
		}

		@Override
		public String toString() {
			return "Season2 [Season2Name=" + Season2Name + ", Season2Desc=" + Season2Desc + "]";
		}

		public void show() {
			System.out.println("这是一个季节");
		}

	}

}
