package com.zwq;

/*
 * 一：枚举类
 * 1.如何自定义枚举类
 * 2.如何使用enum关键字定义枚举类
 * >常用的方法:values() valueOf(String name)
 * >如何让枚举类实现接口：可以让不同的枚举类的对象调用被重写的抽象方法，执行的效果不同。（相当于让每个对象重写抽象方法）
 */
public class TestSeason {

	public static void main(String[] args) {
		Season spring = Season.SPRING;//Season.SPRING：调用Season类的SPRING对象
		System.out.println(spring);//自动调用Season类中重写的toString方法
		spring.show();
		System.out.println(spring.getSeasonName());

	}
	
	//枚举类
	static class Season {
		// 1. 提供类的私有且终态的属性，声明为private final
		private final String seasonName;
		private final String seasonDesc;
		
		// 2.声明为final的属性在构造器中初始化
		private Season (String seasonName,String seasonDesc) {
			this.seasonName = seasonName;
			this.seasonDesc = seasonDesc;
		}
		// 3.通过公共方法来调用属性 
		public String getSeasonName() {
			return seasonName;
		}	
		public String getSeasonDesc() {
			return seasonDesc;
		}
		
		// 4.创建枚举类对象:将枚举类对象声明为public static final
		public static final Season SPRING = new Season("spring", "春暖花开");
		public static final Season SUMMER = new Season("summer", "夏日炎炎");
		public static final Season AUTUMN = new Season("autumn", "秋高气爽");
		public static final Season WINTER = new Season("winter", "白雪皑皑");
	
		@Override
		public String toString() {
			return "Season [seasonName=" + seasonName + ", seasonDesc=" + seasonDesc + "]";
		}
		
		public void show() {
			System.out.println("这是一个季节");
		}
		
	}
	
	
	
	

}
