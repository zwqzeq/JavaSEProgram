package com.zzwwqq;
//线程的死锁      例子：
import javax.naming.InitialContext;

class A {
	public synchronized void foo(B b) {//锁：A的对象a
		try {
			Thread.currentThread().sleep(10);
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		b.last();
	}
	
	public synchronized void last() {//锁：A的对象a
		
	}
}



class B {
	public synchronized void bar(A a) {//锁：B的对象b
		try {
			Thread.currentThread().sleep(10);
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		a.last();
	}
	
	public synchronized void last() {//锁：B的对象b
		
	}
}



public class TestDeadLock2 implements Runnable{

	A a = new A();
	B b = new B();
	
	public void init() {
		a.foo(b);
	}
	
	@Override
	public void run() {
		b.bar(a);
	}

	
	public static void main(String[] args) {
		TestDeadLock2 d1 = new TestDeadLock2();
		new Thread(d1).start();
		d1.init();
	}
	
	
}
