package com.zwq;

/*
 * 创建多线程的方式二：通过实现的方式
 * 
 * 对比一下继承的方式    VS 实现的方式：
 * 1. 联系：public class Thread implements Runnable
 * 2. 哪个方式好？实现的方式优于继承的方式
 *    why?     ①避免了java单继承性的局限性
 *             ②如果多个线程要操作同一份资源，更适合使用实现的方式
 * 
 * 
 * 
 */
// 1.创建一个实现了Runnable接口的类
class PrintNum1 implements Runnable {

	// 2.实现接口的抽象方法
	@Override
	public void run() {
		for(int i = 1; i <= 100; i++) {
			if (i % 2 == 0) {
				System.out.println(Thread.currentThread().getName()+":"+i);
			}
		}
		
	}
	
}
public class TestThread4 {
	public static void main(String[] args) {
		// 3.创建一个Runnable接口实现类的对象
		PrintNum1 p = new PrintNum1();
		
		//p.start();//错误
		//p.run();//错误，不是多线程
	
		//要想启动一个多线程，必须调用start
		// 4.将此对象作为形参传递给Thread类的构造器中，创建Thread类的对象，此对象即为一个线程
		Thread t1 = new Thread(p);
		// 5.调用start()方法启动线程
		t1.start();//启动线程；执行Thread对象生成时构造器形参的对象的run()方法
	
		//在创建一个线程
		Thread t2 = new Thread(p);
		t2.start();
	}
}
