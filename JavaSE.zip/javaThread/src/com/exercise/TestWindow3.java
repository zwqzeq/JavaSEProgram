package com.exercise;



/**
 * 模拟火车站售票窗口，开启三个窗口售票，总票数100张
 * 此程序存在线程安全问题----->使用同步代码块处理。
 *
 */

class Window3 extends Thread {
	static int ticket = 100;//注意：ticket必须设置为static类型的，否则就是300张票
	//Object obj = new Object();
	static Object obj = new Object();
	public void run() {
		while(true) {
//			synchronized (this) {//在本问题中，this表示：w1，w2，w3,相当于有三把锁，不能实现线程的安全
			
			//同样的obj相当于也有三个，因为obj是window3类的成员变量，下面main函数代码中造了三个Windows3类的对象，每个对象都有一个obj，相当于三个obj，即相当于三把锁，不能实现线程的安全
			//如果把obj改为static修饰，即可；因为静态变量为类的所有对象共有；
			synchronized (obj) {//同样的obj相当于也有三个，因为obj是window3类的成员变量，下面main函数代码中造了三个Windows3类的对象，每个对象都有一个obj，相当于三个obj，即相当于三把锁，不能实现线程的安全
			if (ticket > 0) {
					try {
						Thread.currentThread().sleep(10);
					} catch (InterruptedException e) {
						// TODO 自动生成的 catch 块
						e.printStackTrace();
					}
					System.out.println(Thread.currentThread().getName() + "售票，票号为:" + ticket--);
				} else {
					break;
				}
			}
			
			
			//show();不能实现线程安全
				
		}
	}
	
	public synchronized void show() {//this充当的锁，由于创建了三个对象（w1，w2，w3），this相当于被三个对象调用，相当于三把锁
		if (ticket > 0) {
			try {
				Thread.currentThread().sleep(10);
			} catch (InterruptedException e) {
				// TODO 自动生成的 catch 块
				e.printStackTrace();
			}
			System.out.println(Thread.currentThread().getName() + "售票，票号为:" + ticket--);
		}
	}
	
	
	
	
	
}




public class TestWindow3 {
	public static void main(String[] args) {
		Window3 w1 = new Window3();
		Window3 w2 = new Window3();
		Window3 w3 = new Window3();
		
		w1.setName("窗口1");
		w2.setName("窗口2");
		w3.setName("窗口3");
		
		w1.start();
		w2.start();
		w3.start();
	}
}
