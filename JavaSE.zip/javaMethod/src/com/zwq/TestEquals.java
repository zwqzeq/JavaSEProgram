package com.zwq;

import org.junit.Test;

public class TestEquals {
	
	/*
	 * equels():
	 * ①只能处理引用类型变量
	 * ②在Object类，发现equals()仍然比较的是两个引用变量的地址值是否相等
	 * java.lang.Object类，是所有类的根父类
	 * 
	 */
	@Test
	public void test2() {
		Person p1 = new Person();
		Person p2 = new Person();
		System.out.println(p1.equals(p2));//false
		System.out.println(p1 == p2);//false
		
		//像String类  包装类  File类 Date类 这些重写了Object类的equals()方法,比较的是两个对象的“实体内容”是否完全相同。
		String str1 = new String("AA");
		String str2 = new String("AA");
		System.out.println(str1 == str2);//false
		System.out.println(str1.equals(str2));//true,因为String类重写了equals方法，String类中重写的equals方法此时比较的是值而不再是地址
		
		
		
		//关于String类
		String str3 = "AA";
		String str4 = "AA";
		String str5 = new String("AA");
		System.out.println(str3 == str4);//true
		System.out.println(str3.equals(str4));//true
		System.out.println(str3 == str5);//false
		System.out.println(str3.equals(str5));//true
		
		
		

	}
	
	
	
	
	
	
	
	
	
	
	
	/*
	 * ==
	 * 1.基本数据类型（8种）：根据基本数据类型的值判断是否相等。相等返回true，反之返回false
	 * 两端数据类型可以不同，在不同的情况下，也可以返回true。
	 * 2.引用数据类型(类（如String类），接口，枚举，数组)：比较引用类型变量的地址值是否相等
	 */
	@Test
	public void test1() {
	
		int i = 12;
		int j = 12;
		System.out.println(i == j);//true
		char c = 12;
		System.out.println(i == c);//true
		float f = 12.0F;
		System.out.println(i == f);//true
		int k = 65;
		char a = 'A';
		System.out.println(k == a);//true
		
		
		Object obj1 = new Object();
		Object obj2 = new Object();
		System.out.println(obj1);
		System.out.println(obj2);
		System.out.println(obj1 == obj2);//false
		
		Person p1 = new Person();
		Person p2 = new Person();
		Person p3 = p1;
		System.out.println(p1 == p2);//false
		System.out.println(p1 == p3);//true
		
	}
	
	public static void main(String[] args) {
			
	}
}
class Person {
	private String name;
	private int age;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	public Person(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}
	public Person() {
		super();
	}

	
	//手动实现      测试用
//	public String toString() {
//		return "我是一个好人!";
//	}
//	//手动实现 
//	public String toString() {
//		return "Person:name = " + name +", age = "+age;
//	}
	
	//自动实现：鼠标右键--->源码----生成toString()
	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	}
	
}
