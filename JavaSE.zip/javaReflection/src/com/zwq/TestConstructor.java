package com.zwq;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import org.junit.Test;

/**
 * 1. 创建运行时类的对象。使用newInstance(),实际上就是调用了运行时类的无参构造器
 * 例如Object obj = clazz.newInstance();//调用运行时类的无参构造器
 * 也可以调用运行时类的有参构造器 例如：Person p = (Person) cons.newInstance("罗伟",20);
 * 要想能够创建成功：①要求对应的运行时类要有对应的构造器 。②构造器的权限修饰符的权限要足够
 * 
 * 2. getDeclaredConstructors();
 * 得到（仅仅是得到而已）运行时类的所有声明的构造器,与构造器权限无关，（即private修饰的也可以获取）
 * 但是要想使用的话，构造器的权限修饰符的权限要足够，
 * 也就是说如果是private修饰的构造器，必须先开启访问权限：cons.setAccessible(true);//设为true时，才可以调用运行时类Person中private修饰的构造器来创建运行时类的对象        Person p = (Person) cons.newInstance("罗伟",20);//调用运行时类Person中private修饰的构造器来创建运行时类的对象

 * 
 * 
 * 
 * @author asus
 *
 */
public class TestConstructor {
   
	@Test
	public void test() throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		String className = "com.zwq.Person";
		Class clazz = Class.forName(className);
		//创建运行时类的对象。使用newInstance(),实际上就是调用了运行时类的无参构造器
		//调用的是运行时类的无参构造器即Person类的无参构造器
		//要想能够创建成功：①要求对应的运行时类要有无参的构造器 。②构造器的权限修饰符的权限要足够
		Object obj = clazz.newInstance();//调用运行时类的无参构造器
	    Person p = (Person) obj;
	    System.out.println(p);
	}
	
	@Test
	public void test2() throws ClassNotFoundException {
		String className = "com.zwq.Person";
        Class clazz = Class.forName(className);
        Constructor[] cons = clazz.getDeclaredConstructors();//得到运行时类的所有声明的构造器,与构造器权限无关
        for (Constructor c:cons) {
        	System.out.println(c);
        }
	}
	
	//调用指定的构造器,创建运行时类的对象
	@Test
	public void test3() throws ClassNotFoundException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {
		String className = "com.zwq.Person";
        Class<?> clazz = Class.forName(className);
        Constructor<?> cons = clazz.getDeclaredConstructor(String.class,int.class);
        System.out.println(cons);
        cons.setAccessible(true);  //设为true时，才可以调用运行时类Person中private修饰的构造器来创建运行时类的对象
        Person p = (Person) cons.newInstance("罗伟",20);//调用运行时类Person中private修饰的构造器来创建运行时类的对象
        System.out.println(p);
	}
	
}
