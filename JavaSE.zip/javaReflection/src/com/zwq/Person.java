package com.zwq;

@MyAnnotation(value = "atzwq")
public class Person extends Creature<String> implements Comparable,MyInterface{
	public String name;//公共权限
	private int age;//私有权限
	protected int id;//默认权限

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	//创建类时，尽量保留一个无参的构造器
	public Person() {
		super();
		System.out.println("我是Person类的无参构造器-----");
	}

	private Person(String name) {
		super();
		System.out.println("我是Person类的一个参数的构造器----");
		this.name = name;
	}

	private Person(String name, int age) {
		super();
		System.out.println("我是Person类的两个参数的构造器----");
		this.name = name;
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		System.out.print("我是Person类的toString方法------");
		return "Person [name=" + name + ", age=" + age + "]"+"\n";
	}

	@MyAnnotation(value = "abc123")
	public void show() {
		System.out.print("我是Person类的show方法-----");
		System.out.println("我是一个人！");
	}
	
	private void display(String nation) throws Exception{
		System.out.print("我是Person类的display方法-----");
		System.out.println("我的国籍是：" + nation);
	}

	@Override
	public int compareTo(Object o) {
		// TODO 自动生成的方法存根
		return 0;
	}
	
	public static void info () {
		System.out.print("我是Person类的info方法  ---");
		System.out.println("中国人！");
	}
	
	
    class Bird {
		
	}
	
	
}
