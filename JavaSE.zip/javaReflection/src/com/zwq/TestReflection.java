package com.zwq;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.channels.AcceptPendingException;
import java.util.Properties;
import java.util.Scanner;

import javax.swing.text.html.CSS;
import javax.xml.transform.sax.SAXSource;

import org.junit.Test;

//此处class为关键字
public class TestReflection {

	/**
	 * 类加载器
	 * @throws ClassNotFoundException
	 * @throws IOException
	 */
	@Test
	public void test5() throws ClassNotFoundException, IOException {
		ClassLoader clLoader1 = ClassLoader.getSystemClassLoader();//获取系统的类加载器System ClassLoader
		System.out.println(clLoader1);//sun.misc.Launcher$AppClassLoader@6d06d69c
		
		ClassLoader clLoader2 =	clLoader1.getParent();//获取系统的类加载器的父类，扩展类加载器Extension ClassLoader
        System.out.println(clLoader2);//sun.misc.Launcher$ExtClassLoader@2503dbd3
        
        ClassLoader clLoader3 = clLoader2.getParent();//获取系统的类加载器的父类的父类，即引导类加载器 Bootstap ClassLoader
        System.out.println(clLoader3);//null 因为该加载器无法直接获取
        
                
        Class clazz = Person.class;//获取自定义类Person的class对象
        ClassLoader clLoader4 = clazz.getClassLoader();//获取Person类的类加载器
        System.out.println(clLoader4);//sun.misc.Launcher$AppClassLoader@6d06d69c，该结果说明了自定义的类是由系统类加载器加载的
         
        String className = "java.lang.String";
        Class clazz2 = Class.forName(className);
        ClassLoader clLoader5 = clazz2.getClassLoader();
        System.out.println(clLoader5);
        
        //掌握如下
        //法一：要读取的文件在com.zwq包下
        ClassLoader loader = this.getClass().getClassLoader();
        InputStream is = loader.getResourceAsStream("com\\zwq\\jdbc.properties");
       
        //法二：如果要读取的文件在当前工程下
        //FileInputStream is = new FileInputStream(new File("jdbc1.properties"));
        Properties pros = new Properties();
        pros.load(is);
        String name = pros.getProperty("user");
        System.out.println(name);
        String password = pros.getProperty("password");
        System.out.println(password);
        
       
        
        
	}
	
	
	
	
	
	
	


	//如何获取Class的实例（3种）
	@Test
	public void  test4() throws ClassNotFoundException {
		// 1.调用运行时类本身的.class属性
		Class clazz = Person.class;
		System.out.println(clazz.getName());
	    
		Class clazz2 = String.class;
		System.out.println(clazz2.getName());
	
		// 2.通过运行时类的对象获取
		Person p = new Person();
		Class clazz3 = p.getClass();
		System.out.println(clazz3.getName());
	
	    // 3.通过Class的静态方法获取,通过此方式，体会反射的动态性
		String className = "com.zwq.Person";
		Class clazz4 = Class.forName(className);
		System.out.println(clazz4.getName());
	
		//4.（了解）通过类的加载器
		ClassLoader classLoader = this.getClass().getClassLoader();
		Class clazz5 = classLoader.loadClass(className);
		System.out.println(clazz5.getName());

		System.out.println(clazz == clazz3);//true
		System.out.println(clazz == clazz4);//true
		System.out.println(clazz == clazz5);//true

		
		
	}
	
	
	
	/*
	 * java.lang.Class:是反射的源头
	 * 我们创建了一个类，通过编译（javac.exe）,生成对应的.class文件。之后我们使用java.exe加载（JVM的类加载器完成的）
	 * 此.class文件，此.class文件加载到内存以后，就是一个运行时类，存放在缓存区。那么这个运行时类本身就是一个Class的实例
	 * 1. 一个运行时类只加载一次
	 * 2. 有了Class的实例以后，我们才可以进行如下操作：
	 *     1）创建对应你的运行时类的对象
	 *     2）获取对应的运行时类的完整结构（属性，方法，构造器，内部类，父类，所在包，异常，注解）
	 *     3）调用对应的运行时类的指定结构（属性，方法，构造器）
	 *     4）反射的应用：动态代理
	 */
	@Test
	public void test3() {
		Person p = new Person();//创建运行时类的对象
		//通过运行时类的对象调用其getClass()方法，返回其运行时类
		Class clazz = p.getClass();
	    System.out.println(clazz);
	}
	
	
	
	//有了反射以后，可以通过反射创建一个类的对象，并调用其中的结构
	@Test
	public void test2() throws InstantiationException, IllegalAccessException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalArgumentException, InvocationTargetException {
		//此处Class为类
		Class clazz = Person.class;
		
		// 1. 创建clazz对应的运行时类Person类的对象
		Person p = (Person)clazz.newInstance();
	    System.out.println(p);
		// 2. 通过反射调用运行时类的指定的属性
	    // 2.1调用public属性
	    Field f1 = clazz.getField("name");
	    f1.set(p, "LiuDeHua");
	    System.out.println(p);
	
	    // 2.2调用private属性
	    Field f2 = clazz.getDeclaredField("age");
	    f2.setAccessible(true);
	    f2.set(p, 20);
	    System.out.println(p);
	  
	    
	    // 3.通过反射调用运行时类的对象，并调用其中的方法，属性
	  Method m1 = clazz.getMethod("show");
	  m1.invoke(p); 
	    
	  Method m2 = clazz.getMethod("display", String.class); 
	  m2.invoke(p, "CHN");  
   
	}
	
	
	
	

	
	//在有反射以前，如何创建一个类的对象，并调用其中的方法，属性
	@Test
	public void test() throws Exception{
		Person p = new Person();
		p.setAge(10);
		p.setName("TangWei");
		//自动调用Person类中的toString()方法
		System.out.println(p);
		p.show();
		//在测试TestMethod的test()方法时，display改为了private，所以此处会报错
		//p.display("HK");

	}


	
}
