package com.zwq;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

import org.junit.Test;

public class TestField {

	//获取对应的运行时类的属性
	@Test
	public void test() {
		Class clazz = Person.class;
        // 1.getFields():只能获取到运行时类中及其父类中声明为public的属性
		Field [] fields = clazz.getFields();
        for (int i = 0; i < fields.length; i++) {
			System.out.println(fields[i]);		
		}
        System.out.println();
        // 2. getDeclaredFields()获取运行时类本身声明的所有的属性
       Field[] field2 = clazz.getDeclaredFields();
	   for (Field f : field2) {
		   System.out.println(f.getName());
	   }
	   
	}
	
	//权限修饰符，变量名，变量类型
	   //获取属性的各个部分的内容
	   @Test
	   public void test2() {
		Class clazz = Person.class;
        Field[] fields = clazz.getDeclaredFields();
        for (Field f : fields) {
			// 1. 获取每个属性的权限修饰符
        	int i = f.getModifiers();
        	//将权限修饰符对应的整形值，转换为对应的String类型，即1---->public，2---->private,0---->默认
        	System.out.println(i);
        	String str1 = Modifier.toString(i);	
        	System.out.print(str1+" ");
        	// 2. 获取属性的变量类型
        	Class type = f.getType();
        	System.out.print(type.getName() + " ");
        	// 3. 获取属性名
			System.out.print(f.getName());
			
			System.out.println();
		}
	}
	   
	 
	// 调用运行时类中指定的属性
	@Test
	public void test3() throws NoSuchFieldException, SecurityException, InstantiationException, IllegalAccessException {
		Class clazz = Person.class;
		// 1. 获取指定的属性
		// getField(String fieldName):获取运行时类中声明为public 的指定属性名为fieldName的属性
		Field name = clazz.getField("name");
		// 2. 创建运行时类的对象
		Person p = (Person)clazz.newInstance();
		System.out.println(p);
		// 3.将运行时类的指定属性赋值
		name.set(p, "Jerry");
		System.out.println(p);
		
		System.out.println();
		
		//getDeclaredField(String fieldName):获取运行时类中指定的名为fieldName的属性
		//因为age是private修饰的，所以为age设置值时会报错，要想为private修饰的age设置值，需要用getDeclaredField(),并且设置age为可访问，即age.setAccessible(true);
		//Field age = clazz.getField("age");//只能获取运行时类中的公共属性，即public修饰的；所以如果能够访问某个属性的话什么这个属性就是public修饰的，那么age.setAccessible(true);就没有必要
		Field age = clazz.getDeclaredField("age");
		//由于属性权限修饰符的限制，为了保证可以给属性赋值，需要在操作前使得此属性可被操作
		age.setAccessible(true);
		age.set(p, 100);
		System.out.println(p);
		
		//Field id = clazz.getField("id");
		
		
		
	}
	   
}
