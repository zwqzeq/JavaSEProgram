package com.zwq;

import java.io.Serializable;

public interface MyInterface extends Serializable{

}
