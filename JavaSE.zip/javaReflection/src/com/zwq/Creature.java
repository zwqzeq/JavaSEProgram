package com.zwq;

public class Creature<T> {
	//如果去掉public权限，即使用默认权限时，再运行TestField类中的test方法，则不会出现public double com.zwq.Creature.weight
   public double weight;
    
    public void breath() {
    	System.out.println("呼吸！");
    }
}
