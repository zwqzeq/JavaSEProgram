package com.zwq;

import static java.lang.annotation.ElementType.CONSTRUCTOR;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.LOCAL_VARIABLE;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.ElementType.TYPE;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/*
 * 自定义注解
 * 参照SuppressWarnings里面的源代码来写
 */
//Target的值指定某个注解能够去注解什么，比如FIELD指明@Target修饰的注解能够去注解属性，
@Target({TYPE, FIELD, METHOD, PARAMETER, CONSTRUCTOR, LOCAL_VARIABLE})
//@Retention的值指定某个注解生命周期，SOURCE表示编译时丢弃
@Retention(RetentionPolicy.SOURCE)
public @interface MyAnnotation {
	String value() default "hello"; 
}
