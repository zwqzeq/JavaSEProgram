package com.zwq;

import java.lang.annotation.Target;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * 注解
 * 1. JDK提供的常用的注解
 *   @Override:限定重写父类方法，该注释只能用于方法
 *   @deprecated:用于表示每个程序元素（类，方法等）已过时
 *   @SuppressWarnings:抑制编译器警告
 * 2. 如何自定义一个注解：public @interface MyAnnotation{}
 * 3. 元注解：修饰注解的注解，常用的有：@Retention，@Target
 */
public class TestAnnotation {
	public static void main(String[] args) {
		Person p = new Student();
		p.walk();
		p.eat();
		
		//rawtypes:表示ArrayList未使用泛型，unused：表示list变量没有被使用
		@SuppressWarnings({ "rawtypes", "unused" })
		List list = new ArrayList();
		
		@SuppressWarnings("unused")
		int i = 10;
		
		
	}
}

@MyAnnotation(value = "abc")
class Student extends Person {
	
	@Override
	public void walk() {
		System.out.println("学生走路");
	}
	@Override
	public void eat() {
		System.out.println("学生吃饭");
	}
}



class Person {
	String name;
	int age;
	
	public Person() {
		super();
	}
	@MyAnnotation(value = "abc")
	public Person(String name,int age) {
		super();
		this.name = name;
		this.age = age;	
	}
	@MyAnnotation(value = "abc")
	public void walk() {
		System.out.println("走路");
	}
	
	@Deprecated
	public void eat() {
		System.out.println("吃饭");
	}
	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	}
	
	
	
}


