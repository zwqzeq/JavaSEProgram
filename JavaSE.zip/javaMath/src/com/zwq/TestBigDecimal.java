package com.zwq;

import java.math.BigDecimal;
import java.math.BigInteger;

import org.junit.Test;

public class TestBigDecimal {
    
	@Test
	public void test(){
		BigInteger bi = new BigInteger("12433241123");
		BigDecimal bd = new BigDecimal("12435.351");
		BigDecimal bd2 = new BigDecimal("11");
		System.out.println(bi);
		//由于bd不能被bd2整除，即结果不是整数，下面这一句因为没有指定保留几位小数，会报异常
		//System.out.println(bd.divide(bd2));
		//四舍五入，向上取
		System.out.println(bd.divide(bd2, BigDecimal.ROUND_HALF_UP));
	    //四舍五入，向上取，且保留15位小数
		System.out.println(bd.divide(bd2, 15, BigDecimal.ROUND_HALF_UP));
	}
}
