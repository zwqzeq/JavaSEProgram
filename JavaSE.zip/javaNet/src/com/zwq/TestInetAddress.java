package com.zwq;

import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * InetAddress:位于java.net包下
 * 1. InetAddress用来代表IP地址。一个InetAddress对象就代表着一个IP地址
 * 2. 如何创建InetAddress对象：getByName(String host)
 * 3. getHostName():获取IP地址对应的域名
 *    getHostAddress():获取IP地址
 *
 */
public class TestInetAddress {

	public static void main(String[] args) throws UnknownHostException {
       
        	//创建InetAddress对象：getByName(),注意InetAddress类没有构造器，只能使用该类的静态方法
			InetAddress inet  = InetAddress.getByName("www.baidu.com");
			System.out.println(inet);

			//两个方法：
			System.out.println(inet.getHostName());
	        System.out.println(inet.getHostAddress());
	
	        //获取本机IP：
	        InetAddress inet3 = InetAddress.getLocalHost();
	        System.out.println(inet3);	
	        System.out.println(inet3.getHostName());
	        System.out.println(inet3.getHostAddress());
	
	
	}

}
