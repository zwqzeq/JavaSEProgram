package com.zwq;

import static org.hamcrest.CoreMatchers.nullValue;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

import org.junit.Test;
//客户端发送图片文件给服务端，服务端反馈接收状态给客户端
public class TestTCP3 {
	// 客户端
	@Test
	public void Client() {
		Socket sc = null;
		OutputStream out = null;
		InputStream is = null;
		FileInputStream fi = null;
		try {

			// 1. 创建Socket的对象
			sc = new Socket(InetAddress.getByName("127.0.0.1"), 9898);
			out = sc.getOutputStream();
			// 2. 从本地获取一个文件发送给服务端
			fi = new FileInputStream(new File("1.png"));
			byte[] b = new byte[60000];
			byte[] b1 = new byte[100];
			int length;
			while ((length = fi.read(b)) != -1) {
				out.write(b, 0, length);
			}
			// 告诉服务端，信息已经发送完毕
			sc.shutdownOutput();

			// 3. 接收来自于服务端的消息
			is = sc.getInputStream();
			while ((length = is.read(b1)) != -1) {
				String str = new String(b1, 0, length);
				System.out.println(str);
			}
		} catch (UnknownHostException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} finally {
			// 4. 关闭相应的流以及socket对象
			if (is != null) {
				try {
					is.close();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}

			}
			if (out != null) {
				try {
					out.close();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}

			}
			if (fi != null) {
				try {
					fi.close();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}

			}
			if (sc != null) {
				try {
					sc.close();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}

			}
		}

	}

	// 服务端
	@Test
	public void Server() {
		ServerSocket ss = null;
		Socket sc = null;
		InputStream is = null;
		OutputStream out = null;
		FileOutputStream fo = null;
		try {

			byte[] b = new byte[60000];
			int length = 0;
			// 1. 创建一个ServerSocket的对象
			ss = new ServerSocket(9898);
			// 2. 调用其accept（）方法返回一个socket对象
			sc = ss.accept();
			// 3. 将从客户端发来的信息保存到本地
			is = sc.getInputStream();
			fo = new FileOutputStream(new File("2.png"));
			while ((length = is.read(b)) != -1) {
				fo.write(b, 0, length);
			}

			System.out.println("服务端收到来自于" + sc.getInetAddress().getHostAddress() + "的信息成功");
			// 4. 将“接收成功”的信息反馈给客户端
			out = sc.getOutputStream();
			out.write("你发送的图片我已接收成功！".getBytes());
		} catch (FileNotFoundException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} finally {
			// 5. 关闭相应的流和socket及ServerSocket的对象
			if (out != null) {
				try {
					out.close();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}

			}
			if (fo != null) {
				try {
					fo.close();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}

			}
			if (is != null) {
				try {
					is.close();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}

			}
			if (sc != null) {
				try {
					sc.close();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}

			}
			if (ss != null) {

				try {
					ss.close();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}

			}
		}

	}

}
