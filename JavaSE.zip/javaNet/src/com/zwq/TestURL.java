package com.zwq;

import static org.hamcrest.CoreMatchers.nullValue;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

//URL:统一资源定位符，一个URL的对象，对应互联网上一个资源
//我们可以通过URL的对象调用其相应的方法，将此资源读取（下载）
public class TestURL {

	public static void main(String[] args) throws IOException {
		URL url = new URL("http://127.0.0.1:8080/examples/HelloWorld.txt?a=b");
		/**
		 * public String getProtocol() public String getHost() public String
		 * getPort() public String getPath() public String getFile() public
		 * String getRef() public String getQuery()
		 */
		// System.out.println(url.getProtocol());
		// System.out.println(url.getHost());
		// System.out.println(url.getPort());
		// System.out.println(url.getRef());
		// System.out.println(url.getQuery());
		// System.out.println(url.getPath());
		// System.out.println(url.getAuthority());

		// 如何将服务端的资源读取进来：使用openStream()方法
		InputStream is = null;
		try {
			is = url.openStream();
			byte[] b = new byte[34];
			int length = 0;
			while ((length = is.read(b)) != -1) {
				String str = new String(b, 0, length);
				System.out.println(str);
			}
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} finally {
			if (is != null) {
				is.close();
			}
		}

		// 如果既有数据的输入，又有数据的输出，那么则考虑使用URLConnection类
		FileOutputStream fo = null;
		InputStream is2 = null;
		try {
			URLConnection urlconn = url.openConnection();
			fo = new FileOutputStream(new File("abc.txt"));
			is2 = urlconn.getInputStream();
			int length = 0;
			byte[] b1 = new byte[34];

			while ((length = is2.read(b1)) != -1) {
				fo.write(b1, 0, length);
			}
		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} finally {
			if (fo != null) {
				fo.close();

			}
			if (is2 != null) {
				is2.close();
			}
		}

	}
}
