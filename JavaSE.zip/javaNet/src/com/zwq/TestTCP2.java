package com.zwq;

import static org.hamcrest.CoreMatchers.nullValue;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

import org.junit.Test;
//客户端与服务端交互：互相发信息
//注意：sc.shutdownOutput();作用是告诉服务端，信息已发送完毕，如果没有这一句
//服务端不知道客户端发送信息是否发送完毕，所以将一直等着，程序一直停在93行，后面的不会执行，所以客户端没有显示服务端信息
public class TestTCP2 {
	// 客户端
	@Test
	public void Client() {
		Socket sc = null;
		OutputStream out = null;
		InputStream is = null;
		try {
			sc = new Socket(InetAddress.getByName("127.0.0.1"), 8989);
			out = sc.getOutputStream();
			out.write("这是来自客户端信息：我是客户端".getBytes());
			//这一句很关键
			sc.shutdownOutput();
			is = sc.getInputStream();
			byte[] b = new byte[80];
			int len = 0;
			while ((len = is.read(b)) != -1) {
				String str = new String(b, 0, len);
				System.out.println(str);
			}
		} catch (UnknownHostException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} finally {
			if (is != null) {
				try {
					is.close();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}
                
			}
			if (out != null) {
				try {
					out.close();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}

			}
			if (sc != null) {
				try {
					sc.close();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}

			}
		}


	}

	// 服务端
	@Test
	public void Server() {
		ServerSocket ss = null;
		Socket sc = null;
		InputStream is = null;
		OutputStream out = null;
		try {
			
			ss = new ServerSocket(8989);
			sc = ss.accept();
			is = sc.getInputStream();
			byte[] b = new byte[80];
			int len = 0;
			while ((len = is.read(b)) != -1) {
				String str = new String(b, 0, len);
				System.out.println(str);
			}
			out = sc.getOutputStream();
			out.write("这是来自服务端信息：我已收到你的情意".getBytes());
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} finally {
			if (out != null) {
				try {
					out.close();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}
				
			}
			if (is != null) {
				try {
					is.close();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}
				
			}
			
			if (sc != null) {
				try {
					sc.close();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}
			}
			if (ss != null) {
				try {
					ss.close();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}
				
			}
		}

	}

}
