package com.zwq;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

import org.junit.Test;

//UDP编程
public class TestUDP {

	// 发送端
	@Test
	public void send() {
		DatagramSocket ds = null;
		try {
			// 创建数据报套接字
			ds = new DatagramSocket();
			byte[] b = "你好，我是要发送的数据".getBytes();
			// 创建一个数据报，每一个数据报不能大于64K，
			// 都记录着数据信息，和发送端的IP,端口号，
			// 以及要发送到的接收端的IP及端口号。
			DatagramPacket dp = new DatagramPacket(b, 0, b.length, InetAddress.getByName("127.0.0.1"), 9090);
			ds.send(dp);
		} catch (SocketException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} finally {
			// 关闭数据报套接字
			if (ds != null) {
				ds.close();

			}
		}

	}

	// 接收端
	@Test
	public void receive() {
		DatagramSocket ds = null;
		try {
			// 创建数据报套接字
			ds = new DatagramSocket(9090);
			byte[] b = new byte[1024];
			// 创建数据报，用来接收发送数据
			DatagramPacket dp = new DatagramPacket(b, 0, b.length);
			ds.receive(dp);
			// 接收信息转换为字符串，在控制台打印出来
			String str = new String(dp.getData(), 0, dp.getLength());
			System.out.println(str);
		} catch (SocketException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} finally {
			if (ds != null) {
				ds.close();

			}
		}
	}

}
