package com.zwq;

import static org.hamcrest.CoreMatchers.nullValue;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

import org.junit.Test;

//客户端给服务端发送信息，服务端输出此信息到控制台上
//网络编程实际上就是Socket的编程
public class TestTCP {
	
	// 客户端
	@Test
	public void Client() {
		Socket sc = null;
		OutputStream os = null;
		try {
			// 1. 创建一socket的对象，通过构造器指明服务端的IP地址，以及其接收程序的端口号
			sc = new Socket("127.0.0.1", 9090);
			// 2. getOutputStream():发送数据，方法返回OutputStream的对象
			os = sc.getOutputStream();
			// 3. 具体的输出过程
			os.write("我是客户端,请多关照！".getBytes("UTF-8"));// String的getBytes()方法是得到一个字符串的字节数组，但特别要注意的是，本方法将返回该操作系统默认的编码格式的字节数组。如果你在使用这个方法时不考虑这一点，你会发现在一个平台上运行良好的系统，放到另一台机器上会产生意想不到的问题。
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			// 4.关闭相应的流和socket对象 
			if (os != null) {
				try {
					os.close();
				} catch (IOException e) {
					e.printStackTrace();
				}

			}
			if (sc != null) {
				try {
					sc.close();
				} catch (IOException e) {
					e.printStackTrace();
				}

			}
		}
	}
	
	
	//服务端：
	@Test
	public void Server(){
		ServerSocket ss = null;
		Socket sc = null;
		InputStream is = null;
		byte[] b = new byte[32];
		int len;
		try {
			//创建一个ServerSocket的对象，通过构造器指明自身的端口号
			ss = new ServerSocket(9090);
			//调用其accept（）方法返回一个Socket的对象
			sc = ss.accept();		
			//调用Socket对象的getInputStream（）获取一个从客户端发送过来的输入流
			is = sc.getInputStream();
			System.out.println("服务端界面：");
			//对获取的输入流进行操作
			while((len = is.read(b)) != -1){
				String str = new String(b, 0, len);
				System.out.println(str);				
			}
		    System.out.println("服务端的端口号为:"+sc.getLocalPort()+",收到客户端的端口号为："+sc.getPort()+"的信息");
			System.out.println("服务端的套接字为："+sc.getLocalSocketAddress()+", 客户端的套接字为："+sc.getRemoteSocketAddress());	
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} finally {
			//关闭相应的流以及socket，ServerSocket的对象
			if(is != null){
				try {
					is.close();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}
				
			}
			
			if(sc != null){
				try {
					sc.close();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}
				
			}
			
			if(ss != null){
				try {
					ss.close();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}
				
			}
		}
	}
	
	
	
}
